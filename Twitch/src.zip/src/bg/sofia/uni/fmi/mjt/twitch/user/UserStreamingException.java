package bg.sofia.uni.fmi.mjt.twitch.user;

public class UserStreamingException extends Throwable {
    public UserStreamingException(String message) {
        super(message);
    }
}
