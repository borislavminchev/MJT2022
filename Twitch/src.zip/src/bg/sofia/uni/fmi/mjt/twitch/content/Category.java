package bg.sofia.uni.fmi.mjt.twitch.content;

public enum Category {
    GAMES, IRL, MUSIC, ESPORTS
}
